#!/usr/bin/env Rscript
# Функциональные испытания утилиты (10 пунктов программы испытаний). Протокол, журналы и sessionInfo()
# каждого прогона собираются в папку --out.
#
#   Rscript tests/ispytaniya.R --out=протокол
#          [--setA=таблица.csv,метаданные.csv]   набор А (когорта статьи ABC, 107 участников); без него — синтетический заменитель А*
#          [--setB=таблица.csv,метаданные.csv]   набор Б (когорта 2025–2026, 94 образца)
#          [--raw=папка_mzML,метаданные.csv]     сырые данные для п. 1 (нужен xcms)
#          [--cores=4]
if (!isTRUE(l10n_info()$`UTF-8`) && .Platform$OS.type != "windows")
  for (loc in c("C.UTF-8", "en_US.UTF-8")) if (nzchar(suppressWarnings(Sys.setlocale("LC_CTYPE", loc)))) break
args <- commandArgs(trailingOnly = TRUE)
arg <- function(k, d = NULL) { a <- grep(paste0("^--", k, "="), args, value = TRUE); if (length(a)) sub("^[^=]*=", "", a) else d }
self <- sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1])
root <- normalizePath(file.path(dirname(normalizePath(self)), ".."))
source(file.path(root, "R", "zz_setup.R"), encoding = "UTF-8"); load_urometabr(root)
source(file.path(root, "tests", "make_test_data.R"), encoding = "UTF-8")
OUT <- normalizePath(arg("out", "ispytaniya_out"), mustWork = FALSE); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
W <- file.path(OUT, "work"); dir.create(W, showWarnings = FALSE)
CORES <- as.integer(arg("cores", "1"))
P <- data.frame(trial = integer(0), item = character(0), value = character(0), target = character(0), result = character(0))
TR <- if (!is.null(arg("trials"))) as.integer(strsplit(arg("trials"), ",")[[1]]) else NULL   # --trials=4,5,6 — дозапуск пунктов
want <- function(...) is.null(TR) || any(c(...) %in% TR)
if (!is.null(TR) && file.exists(file.path(OUT, "protocol.csv"))) {                     # прежние строки остальных пунктов сохраняются
  P <- as.data.frame(data.table::fread(file.path(OUT, "protocol.csv"), encoding = "UTF-8", colClasses = "character"))
  P$trial <- as.integer(P$trial); P <- P[!P$trial %in% TR, ]
}
add <- function(trial, item, value, target = "", result = "") {
  P[nrow(P) + 1, ] <<- list(trial, item, as.character(value), target, result)
  data.table::fwrite(P, file.path(OUT, "protocol.csv"), bom = TRUE)
  cat(sprintf("[%d] %s: %s %s %s\n", trial, item, value, if (nzchar(target)) paste0("(цель: ", target, ")") else "", result))
}
ok <- function(x) if (isTRUE(x)) "пройден" else "не пройден"

# Прогон проекта; журналы и sessionInfo копируются в протокол
LIGHT <- list(impute = list(maxiter = 3), correct = list(eigen_perm = 100),
              select = list(compare_stages = FALSE, nested_repeats = 1))
LIGHT_TXT <- "облегчённые настройки: ≤ 3 итерации заполнения, 100 перестановок EigenMS, вложенная CV 1 × 5, без сравнения этапов"
RERUN <- if (!is.null(arg("rerun_from"))) as.integer(arg("rerun_from")) else NULL   # --rerun_from=7: пересчёт с модуля N в готовых проектах
run_project <- function(name, table, meta, from = 0, to = 9, light = FALSE, ...) {
  d <- file.path(W, name)
  if (!is.null(RERUN) && to >= RERUN && file.exists(file.path(d, MODULES$dir[MODULES$id == RERUN - 1], "result.rds"))) {
    s <- read_settings(file.path(d, "settings.yaml"))
    prev <- utils::tail(sort(list.files(file.path(d, "logs"), pattern = "^modules_", full.names = TRUE)), 1)
    prev <- as.data.frame(data.table::fread(prev, encoding = "UTF-8")); prev <- prev[prev$module < RERUN, ]
    t0 <- proc.time()[["elapsed"]]; r <- NULL
    tryCatch(utils::capture.output(r <- run_pipeline(s, RERUN, to)), error = function(e) NULL)
    st <- if (!is.null(r)) rbind(prev[, names(r)], r) else data.frame(module = NA, status = "ошибка", time_s = NA, peak_ram_mb = NA)
    dl <- file.path(OUT, "runs", name); dir.create(dl, showWarnings = FALSE, recursive = TRUE)
    file.copy(list.files(file.path(d, "logs"), full.names = TRUE), dl, overwrite = TRUE)
    return(list(dir = d, s = s, status = st, ok = all(st$status %in% c("выполнен", "пропущен")), time = sum(st$time_s, na.rm = TRUE),
                ram = suppressWarnings(max(st$peak_ram_mb, na.rm = TRUE))))
  }
  unlink(d, recursive = TRUE)
  f <- new_project(d, normalizePath(table), normalizePath(meta), project = list(cores = CORES), ...)
  if (light) { s0 <- merge_settings(read_settings(f), LIGHT); write_settings(s0, f) }
  s <- read_settings(f)
  t0 <- proc.time()[["elapsed"]]
  r <- NULL
  tryCatch(utils::capture.output(r <- run_pipeline(s, from, to)), error = function(e) NULL)
  st <- if (!is.null(r)) r else data.frame(module = NA, status = "ошибка", time_s = NA, peak_ram_mb = NA)
  dl <- file.path(OUT, "runs", name); dir.create(dl, showWarnings = FALSE, recursive = TRUE)
  file.copy(list.files(file.path(d, "logs"), full.names = TRUE), dl, overwrite = TRUE)
  list(dir = d, s = s, status = st, ok = all(st$status %in% c("выполнен", "пропущен")), time = proc.time()[["elapsed"]] - t0,
       ram = suppressWarnings(max(st$peak_ram_mb, na.rm = TRUE)))
}
rd <- function(r, id, f) as.data.frame(data.table::fread(file.path(r$dir, MODULES$dir[MODULES$id == id], f), encoding = "UTF-8"))
md5 <- function(r, files) vapply(files, function(f) digest::digest(file = file.path(r$dir, f), algo = "md5"), "")

# ------------------------------------------------------------------ наборы данных
A <- arg("setA"); B <- arg("setB")
if (is.null(A)) { a <- make_set_A_surrogate(file.path(W, "setA_surrogate")); A <- c(a$table, a$metadata); A_real <- FALSE
} else { A <- strsplit(A, ",")[[1]]; A_real <- TRUE }
if (!is.null(B)) B <- strsplit(B, ",")[[1]]
if (want(0)) add(0, "Набор А", if (A_real) paste("реальный:", basename(A[1])) else "синтетический заменитель А* (реальный набор не передан)")
if (want(0)) add(0, "Набор Б", if (is.null(B)) "не передан — пункты для набора Б не выполнялись" else basename(B[1]))

# ------------------------------------------------------------------ 1. форматы входа
if (want(1)) {
fv <- write_format_variants(A[1], file.path(W, "formats"))
ref <- NULL
for (f in c("table.csv", "table.tsv", "table.txt", "table_semicolon.txt", "table_features_in_rows.csv")) {
  r <- run_project(paste0("fmt_", tools::file_path_sans_ext(f)), file.path(fv, f), A[2], 0, 3)
  X <- if (r$ok) load_module(r$s, 3)$X else NULL
  same <- if (is.null(ref)) { ref <- X; TRUE } else isTRUE(all.equal(unname(X), unname(ref)))
  add(1, paste("Формат", f), if (r$ok) sprintf("модули 0–3 выполнены; %d × %d", nrow(X), ncol(X)) else "ошибка", "без ошибок, одинаковый результат",
      ok(r$ok && same))
}
ids <- data.table::fread(A[2], data.table = FALSE, colClasses = "character")$file
rawd <- file.path(W, "raw_stub"); write_raw_stubs(rawd, ids)
d <- file.path(W, "fmt_raw_stub"); unlink(d, recursive = TRUE)
s <- read_settings(new_project(d, "", normalizePath(A[2]), type = "raw", raw_dir = rawd))
invisible(log_start(s)); m0 <- tryCatch({ invisible(utils::capture.output(module0_input(s))); TRUE }, error = function(e) conditionMessage(e))
add(1, "Формат mzML и mzXML: модуль 0 (проверка файлов)", if (isTRUE(m0)) sprintf("%d файлов распознаны", length(ids)) else m0, "файлы распознаны", ok(isTRUE(m0)))
RAW <- arg("raw"); M1 <- arg("module1")
if (!is.null(M1) && file.exists(M1)) {                 # результаты tests/module1_check.R (например, из Docker-образа с xcms)
  m1 <- as.data.frame(data.table::fread(M1, encoding = "UTF-8"))
  for (i in seq_len(nrow(m1))) add(1, paste("Модуль 1 (xcms, проверка module1_check):", m1$check[i]), m1$detail[i], "", m1$result[i])
} else if (!requireNamespace("xcms", quietly = TRUE)) {
  add(1, "Формат mzML и mzXML: модуль 1 (xcms)", "не выполнен: пакет xcms не установлен в среде испытаний", "таблица пиков", "не выполнен")
} else if (is.null(RAW)) {
  add(1, "Формат mzML и mzXML: модуль 1 (xcms)", "не выполнен: не передан --raw", "таблица пиков", "не выполнен")
} else {
  rr <- strsplit(RAW, ",")[[1]]; d <- file.path(W, "fmt_raw"); unlink(d, recursive = TRUE)
  r <- run_project("fmt_raw", "", rr[2], 0, 3, input = list(type = "raw", raw_dir = normalizePath(rr[1])))
  add(1, "Формат mzML/mzXML: модули 0–3 по сырым данным", if (r$ok) sprintf("выполнено за %.0f с", r$time) else "ошибка", "без ошибок", ok(r$ok))
}

}

# ------------------------------------------------------------------ 2. объём сессии; 8. время
subset_set <- function(tab, meta, n, name) {
  t <- data.table::fread(tab, data.table = FALSE, check.names = FALSE, colClasses = list(character = 1))
  m <- data.table::fread(meta, data.table = FALSE, colClasses = "character"); names(m) <- tolower(names(m)); if (is.null(m$sample)) m$sample <- m$file
  isq <- toupper(m$group) == "QC" | grepl("^blank", m$group, ignore.case = TRUE)
  st <- unique(m[!isq, c("sample", "group")]); set.seed(n)
  keep <- unlist(lapply(split(st$sample, st$group), function(x) x[seq_len(round(n * length(x) / nrow(st)))]))
  m2 <- m[isq | m$sample %in% keep, ]; t2 <- t[t[[1]] %in% m2$file, ]
  d <- file.path(W, name); dir.create(d, showWarnings = FALSE)
  data.table::fwrite(t2, file.path(d, "peak_table.csv")); data.table::fwrite(m2, file.path(d, "metadata.csv"))
  c(file.path(d, "peak_table.csv"), file.path(d, "metadata.csv"))
}
for (n in if (want(2)) c(50) else integer(0)) {
  ss <- subset_set(A[1], A[2], n, paste0("subset", n))
  r <- run_project(paste0("volume_", n), ss[1], ss[2])
  add(2, sprintf("Объём %d образцов (набор А%s)", n, if (A_real) "" else "*"),
      sprintf("%s; время %.1f мин; пиковая память R %.0f МБ", if (r$ok) "выполнено" else "ошибка", r$time / 60, r$ram), "50–100 образцов без ошибок", ok(r$ok))
  data.table::fwrite(r$status, file.path(OUT, "runs", paste0("volume_", n), "modules.csv"), bom = TRUE)
}

# ------------------------------------------------------------------ 3. устойчивые признаки; 7. сходимость; 8. время
attach_project <- function(name) {
  d <- file.path(W, name); st <- utils::tail(sort(list.files(file.path(d, "logs"), pattern = "^modules_", full.names = TRUE)), 1)
  st <- as.data.frame(data.table::fread(st, encoding = "UTF-8"))
  list(dir = d, s = read_settings(file.path(d, "settings.yaml")), status = st, ok = all(st$status %in% c("выполнен", "пропущен")),
       time = sum(st$time_s, na.rm = TRUE), ram = max(st$peak_ram_mb, na.rm = TRUE))
}
rA <- if (want(2, 3, 7, 8) || !dir.exists(file.path(W, "setA_full", "09_report"))) run_project("setA_full", A[1], A[2]) else attach_project("setA_full")
if (want(2, 3, 7, 8)) {
filter_rows <- function(r, label) {
  m3 <- load_module(r$s, 3); st <- m3$steps
  for (pr in c("стандартный", "строгий")) {
    x <- st[st$profile == pr, ]; n <- utils::tail(x$n, 1)
    add(3, sprintf("Устойчивых признаков, %s, %s профиль%s", label, pr, if (pr == "строгий") " (база признаков)" else " (анализ, по умолчанию)"),
        sprintf("%d; шаги: %s", n, paste(sprintf("%s — %d", x$step, x$n), collapse = "; ")), "300–800", ok(n >= 300 && n <= 800))
  }
}
filter_rows(rA, sprintf("набор А%s", if (A_real) "" else "*"))
nA_s <- sum(load_module(rA$s, 4)$meta$kind == "sample")
add(2, sprintf("Объём %d образцов (весь набор А%s)", nA_s, if (A_real) "" else "*"),
    sprintf("%s; время %.1f мин; пиковая память R %.0f МБ", if (rA$ok) "выполнено" else "ошибка", rA$time / 60, rA$ram), "50–100 образцов без ошибок", ok(rA$ok))
add(8, sprintf("Полный цикл, набор А%s", if (A_real) "" else "*"), sprintf("%.1f мин; пиковая память R %.0f МБ; по модулям: %s", rA$time / 60, rA$ram,
    paste(sprintf("%d — %.0f с", rA$status$module, rA$status$time_s), collapse = "; ")), "≤ 24–48 ч", ok(rA$ok && rA$time < 24 * 3600))
if (!is.null(B)) {
  rB <- run_project("setB_full", B[1], B[2])
  if (rB$ok) filter_rows(rB, "набор Б") else add(3, "Набор Б", "ошибка обработки", "", "не пройден")
  add(8, "Полный цикл, набор Б", sprintf("%.1f мин; пиковая память R %.0f МБ", rB$time / 60, rB$ram), "≤ 24–48 ч", ok(rB$ok && rB$time < 24 * 3600))
}
stA <- rd(rA, 7, "auroc_steps.csv"); nest <- rd(rA, 7, "nested_cv.csv")
add(7, "Набор А: признаки по этапам (до коррекции → после → ОСФ → СПФ → РОП)", paste(stA$n_features, collapse = " → "))
add(7, "Набор А: средняя AUROC по этапам (описательная)", paste(sprintf("%.3f", stA$mean_auroc_descriptive), collapse = " → "))
add(7, "Набор А, вложенная CV: точность / AUC", sprintf("%.3f / %.3f", nest$accuracy_mean, nest$auc_mean))
}
# ------------------------------------------------------------------ 4–5. набор В: пропуски и корректность
# Набор В строится из таблицы А после стандартного фильтра модуля 3: в исходном экспорте MS-DIAL много почти пустых
# признаков (у набора А — 52 % пропусков), а требование ТЗ «до 20–30 % пропусков» относится к устойчивым признакам.
m3A <- load_module(rA$s, 3)
XA <- m3A$X; colnames(XA) <- m3A$info$original[match(colnames(XA), m3A$info$id)]
A_filt <- file.path(W, "setA_filtered.csv")
data.table::fwrite(data.frame(file = rownames(XA), XA, check.names = FALSE), A_filt)
add_if <- want(4, 5)
for (mp in if (add_if) c(0.20, 0.25, 0.30) else numeric(0)) {
  v <- make_set_V(A_filt, A[2], file.path(W, sprintf("data_setV_%02d", round(100 * mp))), n_spike = 15, missing = mp)
  r <- run_project(sprintf("setV_%02d", round(100 * mp)), v$table, v$metadata, light = TRUE)
  if (!r$ok) { add(4, sprintf("Набор В, %d%% пропусков", round(100 * mp)), "ошибка", "", "не пройден"); next }
  im <- readRDS(file.path(dirname(v$table), "introduced_missing.rds"))
  X5 <- load_module(r$s, 5); info <- X5$info; X4 <- load_module(r$s, 4)
  # ошибка заполнения на внесённых пропусках: сравнение с истинными значениями (в шкале log2)
  tab <- data.table::fread(v$table, data.table = FALSE, check.names = FALSE, colClasses = list(character = 1))
  cols <- names(tab)[-1]; rows <- im$mask_rows
  w <- which(im$mask, arr.ind = TRUE); tv <- im$true_values
  fid <- info$id[match(cols[w[, 2]], info$original)]; smp <- load_module(r$s, 0)$meta[rows[w[, 1]], "sample"]
  okm <- !is.na(fid) & smp %in% rownames(X5$X) & !duplicated(paste(smp, fid))
  mm <- load_module(r$s, 0)$meta; single <- names(which(table(mm$sample[mm$kind == "sample"]) == 1))
  okm <- okm & smp %in% single                                        # без усреднённых повторов
  est <- X5$X[cbind(smp[okm], fid[okm])]
  hm <- half_min_impute(X4$X)[cbind(smp[okm], fid[okm])]
  nr <- function(e) sqrt(mean((log2(e) - log2(tv[okm]))^2)) / stats::sd(log2(tv[okm]))
  add(4, sprintf("Набор В, %d%% пропусков (фактически %.1f%%; %s)", round(100 * mp), v$missing_pct, LIGHT_TXT),
      sprintf("обработан; NRMSE заполнения на внесённых пропусках: лес %.3f, ½ минимума %.3f (n = %d)", nr(est), nr(hm), sum(okm)),
      "без ошибок, ошибка заполнения меньше, чем у ½ минимума", ok(nr(est) < nr(hm)))
  if (mp == 0.25) {
    tr <- v$truth; tid <- info$id[match(tr$column, info$original)]
    u <- rd(r, 7, "uvf_stats.csv"); fs <- rd(r, 7, "ds_d.csv"); fr <- rd(r, 7, "ds_rfe.csv"); ne <- rd(r, 7, "nested_cv.csv")
    sel <- u$id[u$selected]
    add(5, "Набор В (25 % пропусков), поправка Холма (по умолчанию): после ОСФ", sprintf("найдено %d из %d, ложных %d", sum(tid %in% sel), length(tid), sum(!sel %in% tid)))
    # для информации: тот же набор, поправка Бенджамини–Хохберга (FDR) — пересчёт только модуля 7 в копии проекта
    dB <- file.path(W, "setV_25_BH"); unlink(dB, recursive = TRUE); dir.create(dB)
    file.copy(list.files(r$dir, full.names = TRUE), dB, recursive = TRUE)
    sB <- read_settings(file.path(dB, "settings.yaml")); sB$select$p_adjust <- "BH"; write_settings(sB, file.path(dB, "settings.yaml"))
    invisible(utils::capture.output(run_pipeline(read_settings(file.path(dB, "settings.yaml")), 7, 7)))
    uB <- as.data.frame(data.table::fread(file.path(dB, "07_select", "uvf_stats.csv"), encoding = "UTF-8")); selB <- uB$id[uB$selected]
    add(5, "Набор В (25 % пропусков), поправка Бенджамини–Хохберга (FDR), для информации — только модуль 7: после ОСФ",
        sprintf("найдено %d из %d, ложных %d", sum(tid %in% selB), length(tid), sum(!selB %in% tid)))
    add(5, "Набор В: после СПФ / после РОП", sprintf("%d (внесённых %d) / %d (внесённых %d)", ncol(fs) - 2, sum(tid %in% names(fs)), ncol(fr) - 2, sum(tid %in% names(fr))))
    add(5, "Набор В: вложенная CV, точность / AUC", sprintf("%.3f / %.3f", ne$accuracy_mean, ne$auc_mean))
    data.table::fwrite(data.frame(tr, id = tid, found_uvf = tid %in% sel, in_ds_d = tid %in% names(fs), in_ds_rfe = tid %in% names(fr)),
                       file.path(OUT, "setV_truth_vs_found.csv"), bom = TRUE)
  }
}

# ------------------------------------------------------------------ 6. воспроизводимость
if (want(6)) {
keyf <- c("05_impute/imputed.csv", "06_correct/corrected_log2.csv", "07_select/uvf_stats.csv", "07_select/ds.csv", "07_select/ds_d.csv",
          "07_select/ds_rfe.csv", "07_select/model_accuracy.csv", "07_select/nested_cv.csv")
h <- lapply(1:3, function(i) { r <- run_project(sprintf("repro_same_seed_%d", i), A[1], A[2], light = TRUE, project = list(cores = if (i == 3) max(2, CORES) else CORES)); md5(r, keyf) })
same <- all(vapply(h[-1], function(x) identical(x, h[[1]]), TRUE))
add(6, paste0("3 запуска с одним seed (третий — в параллельном режиме; ", LIGHT_TXT, ")"), if (same) "все ключевые таблицы побайтно совпадают (md5)" else "есть различия",
    "полное совпадение", ok(same))
sets <- lapply(1:5, function(i) { r <- run_project(sprintf("repro_seed_%d", i), A[1], A[2], light = TRUE, project = list(seed = 1000 + i, cores = CORES))
  list(rfe = setdiff(names(rd(r, 7, "ds_rfe.csv")), c("sample", "Label")), uvf = setdiff(names(rd(r, 7, "ds.csv")), c("sample", "Label"))) })
stab <- function(k) { L <- lapply(sets, `[[`, k); length(Reduce(intersect, L)) / max(1, length(Reduce(union, L))) }
add(6, "5 запусков с разными seed: доля признаков, отобранных во всех запусках (РОП)", sprintf("%.2f (во всех %d, хотя бы в одном %d)", stab("rfe"),
    length(Reduce(intersect, lapply(sets, `[[`, "rfe"))), length(Reduce(union, lapply(sets, `[[`, "rfe")))))
add(6, "5 запусков с разными seed: то же для ОСФ (не зависит от seed)", sprintf("%.2f", stab("uvf")), "1.00", ok(stab("uvf") == 1))

}
# ------------------------------------------------------------------ 9. полнота отчёта
if (want(9)) {
rep <- file.path(rA$dir, "09_report", "report.html"); html <- if (file.exists(rep)) paste(readLines(rep, encoding = "UTF-8"), collapse = "\n") else ""
need <- c("Сведения о прогоне", "0. Входные данные", "2. Контроль качества", "3. Фильтр", "5. Заполнение", "6. Коррекция", "7. Статистика",
          "8. Визуализация", "9. База признаков", "Журнал прогона", "sessionInfo")
miss <- need[!vapply(need, grepl, TRUE, x = html, fixed = TRUE)]
nimg <- lengths(regmatches(html, gregexpr("data:image/png;base64", html)))
add(9, "HTML-отчёт: разделы и рисунки", sprintf("разделов %d из %d; встроенных рисунков %d; размер %.1f МБ", length(need) - length(miss), length(need), nimg,
    file.size(rep) / 2^20), "все разделы, все рисунки", ok(!length(miss) && nimg >= 8))
add(9, "Табличные результаты", paste(length(list.files(rA$dir, pattern = "\\.csv$", recursive = TRUE)), "CSV-файлов; база:", paste(list.files(file.path(rA$dir, "features_db")), collapse = ", ")))
file.copy(rep, file.path(OUT, "report_setA.html"), overwrite = TRUE)

}
# ------------------------------------------------------------------ 10. установка с нуля
if (want(10))
add(10, "Установка на чистый ПК с Windows", "выполняется вручную по чек-листу (docs/user_guide.md, раздел «Проверка установки»)", "время установки, проблемы", "не выполнен в среде разработки")

writeLines(c(paste("UroMetabR", UROMETABR_VERSION), utils::capture.output(utils::sessionInfo())), file.path(OUT, "session_info_ispytaniya.txt"))
cat("\nПротокол:", file.path(OUT, "protocol.csv"), "\n")
